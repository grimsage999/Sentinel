# Integration Guide for Cognito AI Agent Framework

This guide provides the necessary code snippets and instructions to integrate the new AI agent framework into your Cognito (formerly Sentinel) Replit application. The goal is to achieve full functionality within the specified credit limits, making your application ready for deployment and public use.

## 1. Overview of Changes

We will be adding new services for threat intelligence harvesting and processing, and modifying existing services to leverage this new intelligence. The changes are primarily focused on the backend (FastAPI) application.

## 2. File Structure Changes

First, create a new directory for the threat intelligence services:

```bash
mkdir -p backend/app/services/threat_intelligence
```

## 3. `backend/app/core/config.py` Modifications

Add the following new settings to your `backend/app/core/config.py` file. These will allow you to configure the threat intelligence sources and harvesting frequency.

```python
# Threat Intelligence Configuration
threat_intel_sources: List[str] = Field(
    default=[
        "https://www.cisa.gov/uscert/ncas/alerts.xml",
        "https://www.cisa.gov/uscert/ncas/bulletins.xml",
        "https://krebsonsecurity.com/feed/",
        "https://threatpost.com/feed/"
    ],
    env="THREAT_INTEL_SOURCES"
)
harvest_interval_hours: int = Field(default=6, env="HARVEST_INTERVAL_HOURS")
sqlite_db_path: str = Field(default="./threat_intel.db", env="SQLITE_DB_PATH")
```

## 4. New Service: `backend/app/services/threat_intelligence/harvester.py`

Create a new file `harvester.py` inside `backend/app/services/threat_intelligence/` with the following content. This service will fetch and store threat intelligence from RSS feeds.

```python
import asyncio
import logging
import feedparser
import sqlite3
from datetime import datetime, timezone
from typing import List, Dict, Any

from ...core.config import settings

logger = logging.getLogger(__name__)

class ThreatIntelligenceHarvester:
    def __init__(self):
        self.db_path = settings.sqlite_db_path
        self._initialize_db()

    def _initialize_db(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS threat_intel (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT NOT NULL,
                title TEXT NOT NULL,
                link TEXT NOT NULL UNIQUE,
                published TEXT NOT NULL,
                summary TEXT,
                iocs TEXT,
                timestamp TEXT NOT NULL
            )
        """)
        conn.commit()
        conn.close()
        logger.info(f"Threat intelligence database initialized at {self.db_path}")

    async def harvest_feeds(self):
        logger.info("Starting threat intelligence harvesting...")
        for source_url in settings.threat_intel_sources:
            try:
                feed = feedparser.parse(source_url)
                for entry in feed.entries:
                    await self._process_feed_entry(source_url, entry)
                logger.info(f"Successfully harvested from {source_url}")
            except Exception as e:
                logger.error(f"Error harvesting from {source_url}: {e}")
        logger.info("Threat intelligence harvesting completed.")

    async def _process_feed_entry(self, source: str, entry: Dict[str, Any]):
        link = entry.get("link")
        if not link:
            return

        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM threat_intel WHERE link = ?", (link,))
        if cursor.fetchone():
            logger.debug(f"Entry already exists, skipping: {link}")
            conn.close()
            return

        title = entry.get("title", "No Title")
        published = entry.get("published", datetime.now(timezone.utc).isoformat())
        summary = entry.get("summary", entry.get("description", ""))
        timestamp = datetime.now(timezone.utc).isoformat()

        try:
            cursor.execute("""
                INSERT INTO threat_intel (source, title, link, published, summary, timestamp)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (source, title, link, published, summary, timestamp))
            conn.commit()
            logger.debug(f"Added new threat intel entry: {title} from {source}")
        except sqlite3.IntegrityError:
            logger.warning(f"Duplicate entry detected and skipped: {link}")
        except Exception as e:
            logger.error(f"Error saving feed entry {link}: {e}")
        finally:
            conn.close()

class ThreatIntelligenceProcessor:
    def __init__(self):
        self.db_path = settings.sqlite_db_path

    async def extract_and_store_iocs(self):
        logger.info("Starting IOC extraction and storage...")
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT id, summary, link FROM threat_intel WHERE iocs IS NULL")
        entries_to_process = cursor.fetchall()

        for entry_id, summary, link in entries_to_process:
            iocs = self._extract_iocs_from_text(summary + " " + link)
            if iocs:
                iocs_json = json.dumps(iocs)
                cursor.execute("UPDATE threat_intel SET iocs = ? WHERE id = ?", (iocs_json, entry_id))
                logger.debug(f"Extracted and stored IOCs for entry {entry_id}")
        conn.commit()
        conn.close()
        logger.info("IOC extraction and storage completed.")

    def _extract_iocs_from_text(self, text: str) -> Dict[str, List[str]]:
        # Simple regex-based IOC extraction for credit efficiency
        # This can be enhanced with more sophisticated methods if credits allow
        urls = re.findall(r'https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+', text)
        ips = re.findall(r'\b(?:\d{1,3}\.){3}\d{1,3}\b', text)
        domains = re.findall(r'(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}', text)
        
        # Filter out common false positives for domains (e.g., cisa.gov, krebsonsecurity.com)
        safe_domains = []
        for domain in domains:
            if not any(known_safe in domain for known_safe in ["cisa.gov", "krebsonsecurity.com", "threatpost.com"]):
                safe_domains.append(domain)

        return {"urls": list(set(urls)), "ips": list(set(ips)), "domains": list(set(safe_domains))}

class ThreatIntelService:
    def __init__(self):
        self.db_path = settings.sqlite_db_path

    def get_iocs_context(self, iocs: Dict[str, List[str]]) -> List[str]:
        context_messages = []
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        all_iocs = []
        for ioc_type, ioc_list in iocs.items():
            all_iocs.extend(ioc_list)

        if not all_iocs:
            conn.close()
            return []

        # Query for matching IOCs in the database
        # This is a simplified query; for better performance with large datasets,
        # consider a dedicated search index or vector database (if credits allow)
        for ioc_value in all_iocs:
            cursor.execute("SELECT source, title, link, published FROM threat_intel WHERE iocs LIKE ? LIMIT 1", (f'%"{ioc_value}"%',))
            result = cursor.fetchone()
            if result:
                source, title, link, published = result
                context_messages.append(
                    f"Threat Intelligence Match: An Indicator of Compromise (IOC) '{ioc_value}' "
                    f"was found in a threat intelligence report. "
                    f"Source: {source}, Title: '{title}', Link: {link}, Published: {published}."
                )
        conn.close()
        return context_messages

```

**Note**: You will need to add `import re` at the top of `harvester.py` for the regex functions.

## 5. `backend/app/main.py` Modifications

Update `backend/app/main.py` to include the new background tasks for harvesting and processing. You'll need to import the new services and schedule them during the application's lifespan.

First, add these imports at the top of the file:

```python
import asyncio
from .services.threat_intelligence.harvester import ThreatIntelligenceHarvester, ThreatIntelligenceProcessor
```

Then, modify the `lifespan` function to start the background tasks:

```python
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan manager"""
    # Startup
    logger.info("Starting PhishContext AI API")
    logger.info(f"Primary LLM Provider: {settings.primary_llm_provider}")
    logger.info(f"Fallback LLM Provider: {settings.fallback_llm_provider}")
    
    # Start performance monitoring
    from .utils.performance import performance_monitor
    await performance_monitor.start_background_monitoring()
    logger.info("Performance monitoring started")
    
    # Start cache background cleanup
    from .services.cache_service import analysis_cache
    await analysis_cache.start_background_cleanup()
    logger.info("Cache background cleanup started")
    
    # Initialize and start threat intelligence harvesting and processing
    harvester = ThreatIntelligenceHarvester()
    processor = ThreatIntelligenceProcessor()
    
    async def periodic_harvest():
        while True:
            await harvester.harvest_feeds()
            await processor.extract_and_store_iocs()
            await asyncio.sleep(settings.harvest_interval_hours * 3600) # Convert hours to seconds

    app.state.harvest_task = asyncio.create_task(periodic_harvest())
    logger.info(f"Threat intelligence harvesting scheduled every {settings.harvest_interval_hours} hours.")
    
    yield
    
    # Shutdown
    logger.info("Shutting down PhishContext AI API")
    
    # Cancel harvest task
    if hasattr(app.state, 'harvest_task'):
        app.state.harvest_task.cancel()
        await app.state.harvest_task
        logger.info("Threat intelligence harvesting stopped.")

    # Stop performance monitoring
    await performance_monitor.stop_background_monitoring()
    
    # Stop VirusTotal background service (disabled for now)
    # await background_vt_service.stop()
    # logger.info("VirusTotal background submission service stopped")
    logger.info("Performance monitoring stopped")
    
    # Stop cache background cleanup
    await analysis_cache.stop_background_cleanup()
    logger.info("Cache background cleanup stopped")
    
    # Final memory cleanup
    from .core.security import clear_sensitive_memory
    clear_sensitive_memory()
    logger.info("Final memory cleanup completed")
```

## 6. New Service: `backend/app/services/threat_intelligence/threat_intel_service.py`

Create a new file `threat_intel_service.py` inside `backend/app/services/threat_intelligence/` with the following content. This service provides an interface to query the local threat intelligence knowledge base.

```python
import sqlite3
import json
import logging
from typing import List, Dict

from ...core.config import settings

logger = logging.getLogger(__name__)

class ThreatIntelService:
    def __init__(self):
        self.db_path = settings.sqlite_db_path

    def get_iocs_context(self, iocs: Dict[str, List[str]]) -> List[str]:
        context_messages = []
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        all_iocs_values = []
        for ioc_type, ioc_list in iocs.items():
            all_iocs_values.extend(ioc_list)

        if not all_iocs_values:
            conn.close()
            return []

        # Query for matching IOCs in the database
        # This is a simplified query; for better performance with large datasets,
        # consider a dedicated search index or vector database (if credits allow)
        for ioc_value in all_iocs_values:
            # Search in the 'iocs' JSON column
            cursor.execute("SELECT source, title, link, published FROM threat_intel WHERE iocs LIKE ? LIMIT 1", (f'%"{ioc_value}"%',))
            result = cursor.fetchone()
            if result:
                source, title, link, published = result
                context_messages.append(
                    f"Threat Intelligence Match: An Indicator of Compromise (IOC) '{ioc_value}' "
                    f"was found in a threat intelligence report. "
                    f"Source: {source}, Title: '{title}', Link: {link}, Published: {published}."
                )
        conn.close()
        return context_messages

```

## 7. `backend/app/api/dependencies.py` Modifications

Update `backend/app/api/dependencies.py` to include the `ThreatIntelService` as a dependency.

First, add this import at the top of the file:

```python
from ..services.threat_intelligence.threat_intel_service import ThreatIntelService
```

Then, add a new function to get the `ThreatIntelService` instance:

```python
_threat_intel_service: Optional[ThreatIntelService] = None

def get_threat_intel_service() -> ThreatIntelService:
    """
    Dependency to provide ThreatIntelService
    
    Returns:
        ThreatIntelService instance
    """
    global _threat_intel_service
    if _threat_intel_service is None:
        _threat_intel_service = ThreatIntelService()
        logger.info("ThreatIntelService initialized")
    return _threat_intel_service
```

Finally, modify `get_analysis_services` to include the new service:

```python
def get_analysis_services() -> Dict[str, Any]:
    """
    Dependency to provide all analysis services
    
    Returns:
        Dictionary containing all analysis services
    """
    return {
        "email_parser": get_email_parser(),
        "ioc_extractor": get_ioc_extractor(),
        "llm_analyzer": get_llm_analyzer(),
        "threat_intel_service": get_threat_intel_service() # Add this line
    }
```

## 8. `backend/app/services/llm_analyzer.py` Modifications

Update `backend/app/services/llm_analyzer.py` to use the `ThreatIntelService` to enrich the LLM prompt with relevant threat intelligence.

First, add this import at the top of the file:

```python
from .threat_intelligence.threat_intel_service import ThreatIntelService
```

Then, modify the `analyze_email` method to fetch and include threat intelligence context in the prompt:

```python
    async def analyze_email(
        self, 
        email_content: str, 
        email_headers: Optional[Dict[str, Any]] = None,
        iocs: Optional[IOCCollection] = None,
        request_id: Optional[str] = None,
        threat_intel_service: Optional[ThreatIntelService] = None # Add this parameter
    ) -> AnalysisResult:
        """
        Analyze email content using LLM with caching, fallback and retry logic
        
        Args:
            email_content: Raw email content to analyze
            email_headers: Parsed email headers (optional)
            iocs: Pre-extracted IOCs (optional)
            request_id: Unique request identifier for tracking
            threat_intel_service: ThreatIntelService instance for context enrichment
            
        Returns:
            Structured analysis result
            
        Raises:
            LLMServiceError: When all providers fail
            LLMTimeoutError: When analysis times out
            LLMParsingError: When response cannot be parsed
        """
        start_time = datetime.now(timezone.utc)
        
        if not request_id:
            request_id = f"analysis_{start_time.strftime("%Y%m%d_%H%M%S_%f")}"
        
        # Check cache first for performance optimization
        cached_result = await analysis_cache.get(email_content, email_headers)
        if cached_result:
            logger.debug(
                "Cache hit - returning cached analysis result",
                request_id=request_id,
                cache_age_seconds=(datetime.now(timezone.utc) - cached_result.timestamp).total_seconds()
            )
            
            # Update IOCs if provided (cache doesn't store IOCs)
            if iocs:
                cached_result.iocs = iocs
            
            return cached_result
        
        # Log analysis start with safe metadata
        email_metadata = extract_safe_email_metadata(email_content)
        logger.log_analysis_start(
            request_id=request_id,
            email_length=len(email_content),
            client_ip="internal"  # This will be updated by the API layer
        )
        
        # --- NEW: Get threat intelligence context ---
        threat_context = []
        if iocs and threat_intel_service:
            threat_context = threat_intel_service.get_iocs_context(iocs.model_dump())
            if threat_context:
                logger.info(f"Found {len(threat_context)} threat intelligence matches for IOCs.")
        # -------------------------------------------

        # Build optimized analysis prompt
        # Modify this line to pass threat_context to the prompt builder
        prompt = self.prompt_builder.build_analysis_prompt(email_content, email_headers, threat_context=threat_context)
        
        # Try primary provider first, then fallback
        providers_to_try = self._get_provider_order()
        
        last_error = None
        for provider in providers_to_try:
            try:
                logger.log_llm_request(
                    request_id=request_id,
                    provider=provider,
                    prompt_length=len(prompt)
                )
                
                # Perform analysis with retry logic
                llm_response = await self._analyze_with_retry(provider, prompt)
                
                logger.log_llm_response(
                    request_id=request_id,
                    provider=provider,
                    response_length=len(llm_response),
                    processing_time=(datetime.now(timezone.utc) - start_time).total_seconds(),
                    success=True
                )
                
                # Parse and validate response with optimized parsing
                analysis_result = self._parse_llm_response_optimized(
                    llm_response, 
                    start_time, 
                    iocs or IOCCollection()
                )
                
                # Enhance with MITRE ATT&CK context
                analysis_result = self.prompt_builder.enhance_analysis_with_mitre(analysis_result)
                
                # Cache the result for future requests
                await analysis_cache.set(email_content, analysis_result, email_headers)
                
                # Log successful completion
                processing_time = (datetime.now(timezone.utc) - start_time).total_seconds()
                ioc_count = (len(analysis_result.iocs.urls) + len(analysis_result.iocs.ips) + 
                           len(analysis_result.iocs.domains)) if analysis_result.iocs else 0
                
                logger.log_analysis_complete(
                    request_id=request_id,
                    processing_time=processing_time,
                    llm_provider=provider,
                    success=True,
                    ioc_count=ioc_count
                )
                
                return analysis_result
                
            except Exception as e:
                logger.log_error_with_context(
                    error=e,
                    request_id=request_id,
                    operation=f"LLM analysis with {provider}",
                    provider=provider
                )
                last_error = e
                continue
        
        # All providers failed - try demo mode
        logger.warning("All LLM providers failed, falling back to demo mode")
        return self._create_demo_analysis_result(email_content, email_headers, iocs, start_time)
```

And modify the `_parse_llm_response_optimized` method to accept `threat_context` and include it in the `AnalysisResult` if needed. For simplicity, we'll assume the LLM will integrate it into the `summary` or `recommendations`.

## 9. `backend/app/services/prompt_builder.py` Modifications

Update `backend/app/services/prompt_builder.py` to accept and incorporate the `threat_context` into the LLM prompt.

Modify the `build_analysis_prompt` method signature and content:

```python
    def build_analysis_prompt(
        self, 
        email_content: str, 
        email_headers: Dict[str, Any],
        threat_context: Optional[List[str]] = None # Add this parameter
    ) -> str:
        """
        Builds a comprehensive prompt for LLM email analysis.
        """
        # ... (existing prompt building logic)

        prompt_parts = [
            self.system_prompt,
            "## Email Content for Analysis:",
            email_content,
            "\n## Email Headers:",
            json.dumps(email_headers, indent=2)
        ]

        # --- NEW: Add threat intelligence context to the prompt ---
        if threat_context:
            prompt_parts.append("\n## Relevant Threat Intelligence:")
            for context_item in threat_context:
                prompt_parts.append(f"- {context_item}")
        # ---------------------------------------------------------

        prompt_parts.append(self.output_format_instruction)

        return "\n\n".join(prompt_parts)
```

## 10. `backend/app/api/routes/analysis.py` Modifications

Update `backend/app/api/routes/analysis.py` to pass the `threat_intel_service` to the `llm_analyzer`.

Modify the `analyze_email` endpoint:

```python
async def analyze_email(
    request: Request,
    analysis_request: EmailAnalysisRequest,
    services: Dict[str, Any] = Depends(get_analysis_services)
) -> ApiResponse[AnalysisResult]:
    # ... (existing code)

            # Step 3: Perform LLM analysis
            logger.debug("Starting LLM analysis")
            llm_start_time = datetime.utcnow()
            try:
                analysis_result = await services["llm_analyzer"].analyze_email(
                    email_content=email_body or email_content,
                    email_headers=headers_dict,
                    iocs=iocs,
                    threat_intel_service=services["threat_intel_service"] # Add this line
                )
    # ... (rest of the code)
```

## 11. `requirements.txt` Update

Add `feedparser` to your `backend/requirements.txt` file:

```
feedparser
```

## 12. Deployment to Replit

1.  **Update `backend/requirements.txt`**: Add `feedparser`.
2.  **Update `.env`**: Add the new configuration variables in your `.env` file (or Replit secrets):
    ```
    THREAT_INTEL_SOURCES=https://www.cisa.gov/uscert/ncas/alerts.xml,https://www.cisa.gov/uscert/ncas/bulletins.xml,https://krebsonsecurity.com/feed/,https://threatpost.com/feed/
    HARVEST_INTERVAL_HOURS=6
    SQLITE_DB_PATH=./threat_intel.db
    ```
3.  **Copy Files**: Copy the new `harvester.py` and `threat_intel_service.py` files into `backend/app/services/threat_intelligence/`.
4.  **Modify Existing Files**: Apply the changes to `backend/app/core/config.py`, `backend/app/main.py`, `backend/app/api/dependencies.py`, `backend/app/services/llm_analyzer.py`, and `backend/app/services/prompt_builder.py` as detailed above.
5.  **Install Dependencies**: Run `pip install -r requirements.txt` in your Replit backend environment.
6.  **Run Application**: Start your backend and frontend as usual. The `ThreatIntelligenceHarvester` will start running in the background, populating your `threat_intel.db`.

This setup ensures that your Cognito application will now autonomously gather threat intelligence, enrich its LLM analysis with this context, and provide more informed responses, all while being mindful of credit usage through efficient design and local storage of threat data. The solution is designed to be directly deployable to Replit with minimal configuration.

